Android KTX
===========

**ATTENTION**: This repository is no longer being used for development, tracking issues, or
accepting pull requests.

Please file any bug reports or feature suggestions for core-ktx and the other "KTX" libraries at
https://issuetracker.google.com/issues/new?component=396204

Please contribute to core-ktx and the other "KTX" libraries in AOSP by following the instructions
in the README of https://android.googlesource.com/platform/frameworks/support/

Thanks!
