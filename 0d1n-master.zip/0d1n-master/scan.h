#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <alloca.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/wait.h>
#include <errno.h>
#include <limits.h>
#include <curl/curl.h>
//#include <curl/types.h>
#include <curl/easy.h>

//#include "mem_ops.h"
#include "string_ops.h"
#include "file_ops.h"
#include "spider.h"
 
int threadss=4;
void scan(void *arg);
