#### JSON as a Database

Yes, yes, yes. We can use real Database for this but just keep things simple.