This directory contains tools and resources that the Flutter team uses
during development of the framework. The tools in this directory
should not be necessary for developing Flutter applications, though of
course they may be interesting if you are curious.
