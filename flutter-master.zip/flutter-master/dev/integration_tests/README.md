Automated Flutter integration test suites. Each suite consists of either a
complete Flutter app and a `flutter_driver` specification that drives tests
from the UI, or a native app that is meant to integrate with Flutter for
testing.

Intended for use with devicelab tests.
