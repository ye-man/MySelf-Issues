FastLane documentation
================
This folder contains hermetic scripts to deploy a built APK to the play store.

This is done using the [FastLane](https://fastlane.tools) tool suite.

Deployment can be done manually by Googlers by following
go/flutter-gallery-publish (internal doc).

Deployment is automatically done by Cirrus on tagged branch commits.
