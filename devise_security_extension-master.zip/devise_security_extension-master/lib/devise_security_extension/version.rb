module DeviseSecurityExtension
  VERSION = "0.10.0".freeze
end