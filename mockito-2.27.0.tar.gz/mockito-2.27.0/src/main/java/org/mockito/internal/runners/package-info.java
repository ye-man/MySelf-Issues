/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Internal classes for runners implementations.
 */
package org.mockito.internal.runners;
